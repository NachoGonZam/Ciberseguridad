#XOR de datos binarios
def xor_data(binary_data_1, binary_data_2):
    return bytes([b1 ^ b2 for b1, b2 in zip(binary_data_1, binary_data_2)])

#Ejercicio 1 
#Primera parte
clave_codigo = bytes.fromhex("B1EF2ACFE2BAEEFF")
clave_memoria = bytes.fromhex("91BA13BA21AABB12")

print("Parte 1. La clave en properties es : ",xor_data(clave_codigo,clave_memoria).hex())

#Segunda parte
clave_codigo = bytes.fromhex("B1EF2ACFE2BAEEFF")
clave_produccion = bytes.fromhex("B98A15BA31AEBB3F")

print("Parte 2. La clave en memoria es : ",xor_data(clave_codigo,clave_produccion).hex())

#OTRA FORMA DE RESOLVER LA PRÁCTICA
clave_codigo=0xB1EF2ACFE2BAEEFF
clave_memoria=0x91BA13BA21AABB12
clave_produccion=0xB98A15BA31AEBB3
clave_properties=(hex(clave_codigo^clave_memoria))
clave_memoria2=(hex(clave_codigo^clave_produccion))

print("Parte 1. La clave en properties es : ",clave_properties[2:])
print("Parte 2. La clave en memoria es : ",clave_memoria2[2:])


