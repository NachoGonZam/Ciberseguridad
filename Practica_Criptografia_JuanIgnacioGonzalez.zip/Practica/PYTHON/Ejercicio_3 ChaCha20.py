from Crypto.Cipher import ChaCha20
from base64 import b64decode, b64encode
from Crypto.Random import get_random_bytes
import jks
import os

# Obteniendo clave “cifrado-sim-chacha20-256” de KeyStore
path = os.path.dirname(__file__)

keystore = path + "/KeyStorePracticas"

ks = jks.KeyStore.load(keystore, "123456")

for alias, sk in ks.secret_keys.items():
    if sk.alias == "cifrado-sim-chacha20-256":
        key = sk.key

print("La clave “cifrado-sim-chacha20-256” es: ", key.hex())
#Clave de KeyStore "AF9DF30474898787A45605CCB9B936D33B780D03CABC81719D52383480DC3120"

#Datos de la práctica 3
textoPlano_bytes = bytes('KeepCoding te enseña a codificar y a cifrar', 'UTF-8')
#Se requiere o 256 o 128 bits de clave, por ello usamos 256 bits que se transforman en 64 caracteres hexadecimales
clave = bytes.fromhex(key.hex())
#Importante NUNCA debe fijarse el nonce.
#nonce_mensaje = get_random_bytes(8)
nonce_mensaje = b64decode("9Yccn/f5nJJhAt2S")

#Cifrado
cipher = ChaCha20.new(key=clave, nonce=nonce_mensaje)
texto_cifrado = cipher.encrypt(textoPlano_bytes)
print('Mensaje cifrado en HEX = ', texto_cifrado.hex() )
print('Mensaje cifrado en B64 = ', b64encode(texto_cifrado).decode('utf-8'))
