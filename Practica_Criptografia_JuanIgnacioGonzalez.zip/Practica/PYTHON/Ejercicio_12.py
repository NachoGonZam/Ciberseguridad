import json
import base64
from base64 import b64encode, b64decode
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad


#Ejercicio 12
#Cifrado
textoParaCifrar_bytes = bytes('He descubierto el error y no volveré a hacerlo mal', 'UTF-8')
clave = bytes.fromhex('E2CFF885901B3449E9C448BA5B948A8C4EE322152B3F1ACFA0148FB3A426DB74')
#Nonce debería ser aleatorio
nonce = b64decode('9Yccn/f5nJJhAt2S')
datos_asociados_bytes = bytes("Ejercicio 12", "UTF-8")

#Definimos cifrador
cipher = AES.new(clave, AES.MODE_GCM,nonce=nonce)
#Ciframos los datos asociados
cipher.update(datos_asociados_bytes)
#Ciframos y autenticamos generando un tag. 
texto_cifrado_bytes, tag = cipher.encrypt_and_digest(textoParaCifrar_bytes)

#Recuperamos lo datos
nonce_b64 = b64encode(cipher.nonce).decode('utf-8')
texto_cifrado_b64 = b64encode(texto_cifrado_bytes).decode('utf-8')
datos_asociados_b64 = b64encode(datos_asociados_bytes).decode('utf-8')
tag_b64 =b64encode(tag).decode('utf-8')
mensaje_json = json.dumps({'nonce':nonce_b64, 'datos asociados': datos_asociados_b64, 'tag': tag_b64, 'texto cifrado':texto_cifrado_b64})
print("json: ",mensaje_json)
print("Texto cifrado en b64: ",texto_cifrado_b64)
print("Texto cifrado en hexadecimal: ",bytes(base64.b64decode(texto_cifrado_b64)).hex())
