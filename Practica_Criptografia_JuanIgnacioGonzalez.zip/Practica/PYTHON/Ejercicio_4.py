import jwt


#jwt bueno
print("JWT bueno")

encoded_jwt_bueno = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c3VhcmlvIjoiRG9uIFBlcGl0byBkZSBsb3MgcGFsb3RlcyIsInJvbCI6ImlzTm9ybWFsIiwiaWF0IjoxNjY3OTMzNTMzfQ.gfhw0dDxp6oixMLXXRP97W4TDTrv0y7B5YjD0U8ixrE" 

decode_jwt_bueno = jwt.decode(encoded_jwt_bueno,"Con KeepCoding aprendemos", algorithms="HS256")

print(decode_jwt_bueno)

#jwt hacker
print("JWT hacker")

encoded_jwt_hacker = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c3VhcmlvIjoiRG9uIFBlcGl0byBkZSBsb3MgcGFsb3RlcyIsInJvbCI6ImlzQWRtaW4iLCJpYXQiOjE2Njc5MzM1MzN9.krgBkzCBQ5WZ8JnZHuRvmnAZdg4ZMeRNv2CIAODlHRI" 

decode_jwt_hacker = jwt.decode(encoded_jwt_hacker,"Con KeepCoding aprendemos", algorithms="HS256")

print(decode_jwt_hacker)