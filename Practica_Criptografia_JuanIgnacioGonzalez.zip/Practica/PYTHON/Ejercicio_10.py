

#Claves publicas y privadas
pedro_public = "D730BE196E466101"
pedro_priv = "D730BE196E466101"
rrhh_publi = "3869803C684D287B"
rrhh_priv = "3869803C684D287B"
