from Crypto.Protocol.KDF import HKDF
from Crypto.Hash import SHA512
import secrets
import jks
import os

#Ejercicio 14
#Obteniendo clave “cifrado-sim-aes-256” de KeyStore
path = os.path.dirname(__file__)

keystore = path + "/KeyStorePracticas"

ks = jks.KeyStore.load(keystore, "123456")

for alias, sk in ks.secret_keys.items():
    if sk.alias == "cifrado-sim-aes-256":
        master_key = sk.key

print("La clave “cifrado-sim-aes-256” es: ", master_key.hex())

identificador_dispositivo = bytes.fromhex("e43bb4067cbcfab3bec54437b84bef4623e345682d89de9948fbb0afedc461a3")
clave = HKDF(master_key, 32, identificador_dispositivo, SHA512, 1)

print("La clave obtenida es: ", clave.hex())
