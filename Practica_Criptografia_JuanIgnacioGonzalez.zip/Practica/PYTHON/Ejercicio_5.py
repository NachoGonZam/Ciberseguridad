import hashlib

#Ejercicio 5
#Primera parte, comprobar que tipo de hash SHA 3 generamos si sabemos que el texto es
#"En KeepCoding aprendemos cómo protegernos con criptografía"
#y el hash es "bced1be95fbd85d2ffcce9c85434d79aa26f24ce82fbd4439517ea3f072d56fe"
primera_parte = hashlib.sha3_256()

primera_parte.update(bytes("En KeepCoding aprendemos cómo protegernos con criptografía","UTF-8"))
print("---Primera parte---")
#nombre
print("Tipo de hash: ",primera_parte.name)
#longitud
print("Longitud: ",primera_parte.digest_size)
#hash
print("Comprobación hash: ",primera_parte.hexdigest())

#Segunda parte, hacemos un SHA2 y obtenemos el siguiente hash
#"4cec5a9f85dcc5c4c6ccb603d124cf1cdc6dfe836459551a1044f4f2908aa5d63739506f6468833d77c07cfd69c488823b8d858283f1d05877120e8c5351c833"
#que hash hemos realizado?
segunda_parte = hashlib.sha512()
segunda_parte.update(bytes("En KeepCoding aprendemos cómo protegernos con criptografía", "utf8"))
print("---Segunda parte---")
#nombre
print("Tipo de hash: ",segunda_parte.name)
#longitud
print("Longitud: ",segunda_parte.digest_size)
#hash
print("Comprobación hash: " + segunda_parte.digest().hex())

#Tercer parte, realizar un hash SHA3_256 con el texto "En KeepCoding aprendemos cómo protegernos con criptografía."
tercera_parte = hashlib.sha3_256()

tercera_parte.update(bytes("En KeepCoding aprendemos cómo protegernos con criptografía.","UTF-8"))
print("---Tercera parte---")
#hash
print("Hash de la tercera pregunta: ",tercera_parte.hexdigest())